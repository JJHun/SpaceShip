﻿using UnityEngine;
using System.Collections;

public class hpManager : MonoBehaviour {

	public int health = 1;

	void OnTriggerEnter(Collider other){
		--health;
		if (health <= 0) {
			gameObject.SetActive (false);
			//Destroy (gameObject);
		}
	}

}
