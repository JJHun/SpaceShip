﻿using UnityEngine;
using System.Collections;

public class Assemble : MonoBehaviour {

    GameObject booster;
    GameObject body;
    GameObject weapon;

	// Use this for initialization
	void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {
        
        
	}

    public static void SetComponent(string component)
    {
        if(component == "body1")
        {

        }
        else if (component == "body2")
        {

        }
        else if (component == "booster1")
        {

        }
        else if (component == "booster2")
        {

        }
        else if (component == "weapon1")
        {

        }
        else if (component == "weapon2")
        {

        }
        else if (component == "weapon3")
        {

        }
    }

}
