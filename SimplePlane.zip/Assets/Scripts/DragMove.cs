﻿using UnityEngine;
using System.Collections;

public class DragMove : MonoBehaviour {

	Vector3 position;

	bool isDrag = false;
	Vector3 dragPos;

	// Use this for initialization
	void Start () {
		position = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0)) {
			isDrag = true;
			dragPos = Input.mousePosition;
		}

		if (Input.GetMouseButtonUp(0)){
			isDrag = false;
		}

		if (isDrag) {
			position.x += (Input.mousePosition.x - dragPos.x) / 32.0f;
			position.z += (Input.mousePosition.z - dragPos.z) / 32.0f;

			dragPos = Input.mousePosition;
		}

		transform.position = position;

	}
}
