﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BulletLauncher : MonoBehaviour {

	public GameObject bullet1;
    public GameObject bullet2;
    public GameObject bullet3;
    public GameObject[] bList;

    int bType = 0;
	public float fps = 1;  // 초당 발사

	public int poolSize = 5;  // 미리 만들어둘 bullet 개수
	List<GameObject> pool = new List<GameObject>();

	// Use this for initialization
	void Start () {
        bList = new GameObject[3];
        bList[0] = bullet1;
        bList[1] = bullet2;
        bList[2] = bullet3;
        
		for (int i = 0; i < poolSize; ++i) {
			GenerateBullet (bType);
		}
		StartCoroutine (FireBullet());
	}

	void OnDestroy(){
		foreach( var clone in pool ){
			Destroy(clone);
		}
	}

	GameObject GenerateBullet(int bulletType){
		var clone = Instantiate (bList[bulletType]);
		clone.SetActive (false);
		pool.Add (clone);
		return clone;
	}

	GameObject PopBulletFromPool(){
		GameObject result = null;
		if( pool.Exists(clone => clone.activeSelf == false )){
			result = pool.Find (clone => clone.activeSelf == false); 
		}
		else{
			result = GenerateBullet (bType);
		}
		return result;
	}

	IEnumerator FireBullet(){  // co루틴
		// Debug.Log("first");
		//yield return null;
		// Debug.Log("second");
		while (true) {
			var clone = PopBulletFromPool ();
			clone.transform.position = transform.position;
			clone.SetActive (true);

            
			//Instantiate (bullet, transform.position, Quaternion.identity);
			yield return new WaitForSeconds ( 1/fps );
		}
	}
}
