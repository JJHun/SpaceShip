﻿using UnityEngine;
using System.Collections;

public class Remover : MonoBehaviour {
    /*
	void OnCollisionEnter(Collider other){
	//	Destroy(other.gameObject);
		other.gameObject.SetActive(false);
	}
    */
	void OnTriggerEnter(Collider other){
		//Destroy(other.gameObject);
		other.gameObject.SetActive(false);
	}
}
